package bdm;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class login implements ActionListener  {
	JButton b,enter;
	JTextField name;
	JPasswordField pswd ;
	public login() {
		
        JFrame f = new JFrame("Password");
        
        JLabel llb=new JLabel("User Name:");
        llb.setFont(new Font("Trebuchet MS", Font.BOLD, 19));
        llb.setBounds(346, 125, 104, 50);
        
		name=new JTextField();
		name.setFont(new Font("Tahoma", Font.PLAIN, 15));
		name.setBounds(487, 125, 150, 41);
        
        pswd = new JPasswordField ();
        pswd.setFont(new Font("Tahoma", Font.PLAIN, 15));
        pswd.setBounds(487, 199, 150, 41);
		//tb.setForeground(Color.WHITE);
		
		JLabel l = new JLabel("Password:");
		l.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		l.setBounds(346, 199, 104, 50);
		
		b = new JButton("Close");
		b.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		b.setBounds(615, 276, 80, 30);
		b.addActionListener(this);
		
		enter = new JButton("LogIn");
		enter.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		enter.setBounds(453, 276, 80, 30);
		enter.addActionListener(this);
		f.getContentPane().setLayout(null);
		
		f.getContentPane().add(l);
		f.getContentPane().add(pswd);
		f.getContentPane().add(b);
		f.getContentPane().add(name);
		f.getContentPane().add(llb);
		f.getContentPane().add(enter);
		
	    f.setSize(876,585);
	    f.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		String st=name.getText();
		String str=pswd.getText();
		if (e.getSource()==enter) {
			
			if(str.equals("viggy")&&name.getText()=="Roopa") {
				
				/* home page coding
				 * 
				 */
			}
			if(st.equals("Roopa")) {
				
			}
			else
				name.setBackground(Color.RED);
			if(str.equals("viggy")) { 
				
			}
			else
				pswd.setBackground(Color.RED);
		}
		if(e.getSource()==b) {
			
		}
		int a=JOptionPane.showConfirmDialog(null, "Do you really want to close the Application ?","Select",JOptionPane.YES_NO_OPTION);
		if(a==0)
			System.exit(0);
		
	}

	public static void main(String[] args) {
		new login();

	}

}

