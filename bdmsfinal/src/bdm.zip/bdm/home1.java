package bdm;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class home1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home1 frame = new home1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public home1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 532);
		ImageIcon image =new ImageIcon("C:\\Users\\Krishna\\Downloads\\wp4323509-blood-donation-wallpapers.jpg");
		JLabel llb=new JLabel();
		llb.setBounds(0,0,1377,730);
		llb.setIcon(image);
		contentPane.add(llb);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu seeker = new JMenu("Seeker");
		seeker.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(seeker);
		
		JMenuItem sek_Add = new JMenuItem("Add");
		sek_Add.setFont(new Font("Times New Roman", Font.BOLD, 15));
		sek_Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//edrfghjkliuy7t6rerw
				new Update().setVisible(true);
			}
		});
		seeker.add(sek_Add);
		
		JMenuItem sek_update = new JMenuItem("Update/Delete");
		sek_update.setFont(new Font("Times New Roman", Font.BOLD, 15));
		seeker.add(sek_update);
		
		JMenuItem sek_view = new JMenuItem("View All");
		sek_view.setFont(new Font("Times New Roman", Font.BOLD, 15));
		seeker.add(sek_view);
		
		JMenu hospital = new JMenu("Hospital");
		hospital.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(hospital);
		
		JMenuItem hos_add = new JMenuItem("Add");
		hos_add.setFont(new Font("Times New Roman", Font.BOLD, 15));
		hospital.add(hos_add);
		
		JMenuItem hos_update = new JMenuItem("Update/Delete");
		hos_update.setFont(new Font("Times New Roman", Font.BOLD, 15));
		hospital.add(hos_update);
		
		JMenuItem hos_View = new JMenuItem("View All");
		hos_View.setFont(new Font("Times New Roman", Font.BOLD, 15));
		hospital.add(hos_View);
		
		JMenu Request = new JMenu("Search");
		Request.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(Request);
		
		JMenuItem req_loc = new JMenuItem("Location");
		req_loc.setFont(new Font("Times New Roman", Font.BOLD, 15));
		Request.add(req_loc);
		
		JMenuItem req_bg = new JMenuItem("Blood Group");
		req_bg.setFont(new Font("Times New Roman", Font.BOLD, 15));
		Request.add(req_bg);
		
		JMenu bloodgrp = new JMenu("Blood Stock");
		bloodgrp.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(bloodgrp);
		
		JMenuItem inc = new JMenuItem("Increase");
		inc.setFont(new Font("Times New Roman", Font.BOLD, 15));
		bloodgrp.add(inc);
		
		JMenuItem dec = new JMenuItem("Decrease");
		dec.setFont(new Font("Times New Roman", Font.BOLD, 15));
		bloodgrp.add(dec);
		
		JMenuItem details = new JMenuItem("Details");
		details.setFont(new Font("Times New Roman", Font.BOLD, 15));
		bloodgrp.add(details);
		
		JMenu mnNewMenu = new JMenu("Request");
		mnNewMenu.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Add");
		mntmNewMenuItem.setFont(new Font("Times New Roman", Font.BOLD, 15));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Update/Delete");
		mntmNewMenuItem_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenu donor = new JMenu("Donor");
		donor.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(donor);
		
		JMenuItem donor_add = new JMenuItem("Add");
		donor_add.setFont(new Font("Times New Roman", Font.BOLD, 15));
		donor.add(donor_add);
		
		JMenuItem donor_update = new JMenuItem("Update/Delete");
		donor_update.setFont(new Font("Times New Roman", Font.BOLD, 15));
		donor.add(donor_update);
		
		JMenuItem donor_det = new JMenuItem("Details");
		donor_det.setFont(new Font("Times New Roman", Font.BOLD, 15));
		donor.add(donor_det);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//JLabel llbb = new JLabel("");
		//llbb.setBounds(0, 0, 866, 481);
		//contentPane.add(llbb);
	}

}